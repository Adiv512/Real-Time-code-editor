
# Live Code Editor

Just a simple Live Code Editor made using HTML/CSS and JavaScript, without framework.


## Roadmap

- Additional browser support

- Line numbers

- Responsive

- Light/Dark theme

- Auto complete

